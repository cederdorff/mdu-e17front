<meta content="0; URL='http://eaaa.cederdorff.com/mdu-e17front/cederdorff_com_wp_api/''" http-equiv"refresh">
<!-- just in case the meta tag is not read properly, here is plan B: a JS redirect -->
<script type="text/javascript">
  window.location = 'http://eaaa.cederdorff.com/mdu-e17front/cederdorff_com_wp_api/';
</script>
